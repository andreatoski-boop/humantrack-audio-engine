import express from 'express';
import multer from 'multer';
import {spawn} from 'node:child_process';
import {mkdtemp,rm,stat} from 'node:fs/promises';
import {createReadStream} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
const app=express();
const upload=multer({dest:'/tmp/uploads',limits:{fileSize:200*1024*1024}});
const port=Number(process.env.PORT||8080);
app.get('/health',(_,res)=>res.json({ok:true,service:'humantrack-audio-engine'}));
const profiles={
  gentle:['-af','highpass=f=25,lowpass=f=19500,acompressor=threshold=-18dB:ratio=1.25:attack=20:release=180,equalizer=f=2800:t=q:w=1.2:g=0.35','-ar','48000'],
  warm:['-af','highpass=f=28,lowpass=f=19000,equalizer=f=180:t=q:w=1:g=0.45,equalizer=f=5200:t=q:w=1.4:g=-0.35,acompressor=threshold=-20dB:ratio=1.18:attack=28:release=220','-ar','48000'],
  dynamic:['-af','highpass=f=24,lowpass=f=19800,acompressor=threshold=-16dB:ratio=1.15:attack=35:release=260,equalizer=f=900:t=q:w=1.1:g=-0.25,equalizer=f=3600:t=q:w=1.3:g=0.3','-ar','48000']
};
app.post('/process',upload.single('audio'),async(req,res)=>{
 if(!req.file)return res.status(400).json({error:'audio_required'});
 const variant=String(req.body.variant||'gentle'); const args=profiles[variant];
 if(!args)return res.status(400).json({error:'unknown_variant'});
 const format=String(req.body.format||'wav16');
 const dir=await mkdtemp(path.join(tmpdir(),'ht-')); const ext=format==='mp3'?'mp3':'wav'; const out=path.join(dir,'result.'+ext);
 let enc=format==='wav24'?['-c:a','pcm_s24le']:format==='mp3'?['-c:a','libmp3lame','-b:a','320k']:['-c:a','pcm_s16le'];
 const ff=spawn('ffmpeg',['-y','-i',req.file.path,...args,...enc,out]); let err=''; ff.stderr.on('data',d=>err+=d.toString());
 ff.on('close',async code=>{try{if(code!==0)return res.status(500).json({error:'ffmpeg_failed',detail:err.slice(-1000)});const s=await stat(out);res.setHeader('Content-Type',ext==='mp3'?'audio/mpeg':'audio/wav');res.setHeader('Content-Length',String(s.size));res.setHeader('Content-Disposition',`attachment; filename="humantrack-${variant}.${ext}"`);const stream=createReadStream(out);stream.pipe(res);stream.on('close',async()=>{await rm(dir,{recursive:true,force:true});await rm(req.file.path,{force:true});});}catch(e){res.status(500).json({error:'output_failed'});}});
});
app.listen(port,'0.0.0.0',()=>console.log(`HUMANTRACK audio engine on ${port}`));
